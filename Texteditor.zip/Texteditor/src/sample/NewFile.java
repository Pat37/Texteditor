package sample;

        import javafx.stage.FileChooser;

        import java.awt.*;


public class NewFile {


    public static void NewFile(){



    }






}

